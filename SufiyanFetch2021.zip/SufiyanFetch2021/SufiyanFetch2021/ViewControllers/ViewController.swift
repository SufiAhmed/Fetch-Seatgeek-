//
//  ViewController.swift
//  SufiyanFetch2021
//
//  Created by Sufiyan Ahmed on 2/5/21.
//
// Purpose: Main View Controller which handles everything inside the Tableview

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate
{
  
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
   //creating two variables to use in this view from events data
    var events = [Event]()
    var filterEvents = [Event]()
    let parser = Parser()
   // let imageStore = ImageStore()
    
    var searchIsActive = false
    var searchResult = [String]()
    
  //  let cellID = "cell"
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //calling the parser funtion to prase the JOSN data and send it to events
        parser.parse()
        {
            data in
            self.events = data
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
        // setting up tableview
        self.tableView.rowHeight = 125
        tableView.dataSource = self
        self.searchBar.delegate = self
        searchBar.returnKeyType = UIReturnKeyType.done
        // Do any additional setup after loading the view.
        
        //tableView.register(TableViewCell.self, forCellReuseIdentifier: "cell")
    }
    
    //MARK: TableView
    
    // Tableview function handling the population of JSON data into table
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        //if else statement regarding if search is on or not
        if searchIsActive
        {
            return filterEvents.count
        }
        else
        {
        return events.count
        }
    }
    
    // Tableview function responsible to send respective data to specific cells outlined
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell: TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        
        //If else statment returning data depending if search bar is active or not
        if searchIsActive
       {
        cell.mainTitleLabel.text = self.filterEvents[indexPath.row].short_title
        cell.mainLocationLabel.text = self.filterEvents[indexPath.row].venue.display_location
        //geting date and time into string fromat for UILabel
        var get_OutputStr = convertDateFormat(viewDate: self.filterEvents[indexPath.row].datetime_utc)
        cell.mainDateLabel.text = get_OutputStr
        //for specific images formating into string and then using connection to get images
        let url = URL(string: filterEvents[indexPath.row].performers[0].images.huge)
        let data = try? Data(contentsOf: url!)
        cell.mainImageView.image = UIImage(data: data!)
       }
        else
       {
        cell.mainTitleLabel.text = self.events[indexPath.row].short_title
        cell.mainLocationLabel.text = self.events[indexPath.row].venue.display_location
        var get_OutputStr = convertDateFormat(viewDate: self.events[indexPath.row].datetime_utc)
        cell.mainDateLabel.text = get_OutputStr
        let url = URL(string: events[indexPath.row].performers[0].images.huge)
        let data = try? Data(contentsOf: url!)
        cell.mainImageView.image = UIImage(data: data!)
       }
        return cell
    }
    
    
    //segue function, sending specific data to detail View from specific table cell selected
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        //segue to view with this identity
        if(segue.identifier == "SHOWDETAIL")
        {
            let destVC = segue.destination as! DetailViewController
            //send the data of only that specific cell only
            if let indexPath = self.tableView.indexPathForSelectedRow
            {
                
                let topEvents:Event = events[indexPath.row]
                destVC.tvTittleLabel = topEvents.short_title
                var get_OutputStr = convertDateFormat(viewDate: topEvents.datetime_utc)
                destVC.tvTimeLabel = get_OutputStr
                destVC.tvLocationLabel = topEvents.venue.display_location
                
                destVC.tvImage = topEvents.performers[0].images.huge
                
            }
        }
    }
    
    
    //Search function which will look up keyword regaring name of event, location, and event type
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        filterEvents = events.filter( { JSONevent in
            let userFind = "\(JSONevent.short_title) \(JSONevent.venue.display_location) \(JSONevent.type)"
            return userFind.range(of: searchText, options: .caseInsensitive) != nil
        })
        
        searchIsActive = true
        tableView.reloadData()
    }
    
    // if search cancel button is clicked, reload data to orignal view
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar)
    {
        searchIsActive = false
        searchBar.text = nil
        self.tableView.reloadData()
        searchBar.resignFirstResponder()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        searchBar.resignFirstResponder() // hides the keyboard.
        //doThingsForSearching()
    }
    
    //Date&time formatter function to get into ISO format
    func convertDateFormat(viewDate: String) -> String
    {
        //date&time input format
         let inputDateFormatter = DateFormatter()
         inputDateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
         let inputDate = inputDateFormatter.date(from: viewDate)
        // date&time format we want returned
         let convertedDateFormatter = DateFormatter()
         convertedDateFormatter.dateFormat = "MMM dd yyyy h:mm a"
        // send back formatted date and time in the above table function 
         return convertedDateFormatter.string(from: inputDate!)
    }
    
}

