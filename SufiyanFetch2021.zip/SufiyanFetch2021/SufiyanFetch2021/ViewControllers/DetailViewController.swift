//
//  DetailViewController.swift
//  SufiyanFetch2021
//
//  Created by Sufiyan Ahmed on 2/5/21.
//
//  Purpose: Handles all events in detail view controller


import UIKit

class DetailViewController: UIViewController
{
   //var  events = [Event]()
    // Connections for detail lables in detailView
    @IBOutlet weak var detailImageView: UIImageView!
    @IBOutlet weak var detailTitleLabel: UILabel!
    @IBOutlet weak var detailLocationLabel: UILabel!
    @IBOutlet weak var detailTimeLabel: UILabel!
    
    //local varibales that were used in viewController to pass data into lables
    var tvTittleLabel: String!
    var tvLocationLabel: String!
    var tvImage: String!
    var imgURl: String!
    var tvTimeLabel: String!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // letting title become header of view
        navigationItem.title = tvTittleLabel
        //passing the local varibale data to labels
        detailTitleLabel.text = tvTittleLabel
        detailLocationLabel.text = tvLocationLabel
        detailTimeLabel.text = tvTimeLabel
        let url = URL(string: tvImage)
        let data = try? Data(contentsOf: url!)
        detailImageView.image = UIImage(data: data!)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
  

}
