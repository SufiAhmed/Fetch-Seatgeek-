//
//  Parser.swift
//  SufiyanFetch2021
//
//  Created by Sufiyan Ahmed on 2/5/21.
//
//  Purpose: Parser model which will handle parsing the JSON data for us

import Foundation

struct Parser
{
    // the function that gets called in viewController to parse for us
    func parse (completion: @escaping ([Event]) -> ())
    {
        let apiURL = URL(string: "https://api.seatgeek.com/2/events?client_id=MjE1MjAyNzl8MTYxMTg3OTE3OS45NDg0MTg")
        
        URLSession.shared.dataTask(with: apiURL!)
        {
            data, response, error in
            if error != nil
            {
                // if error stop JSON process
                print(error?.localizedDescription)
                return
            }
            do{
                // if no error start Parase with ROOT Struct
            let result = try JSONDecoder().decode(Root.self, from: data!)
                // completion handler to get events data
                completion(result.events)
                // print data to see if its parsing correctly 
              //  print(result)
            } catch{
        }
        }.resume()
}
}
