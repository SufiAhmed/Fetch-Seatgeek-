//
//  ImageStore.swift
//  SufiyanFetch2021
//
//  Created by Sufiyan Ahmed on 2/5/21.
//

import Foundation
import UIKit

class ImageStore {
    
    // static var shared = ImageStore()
    
    let imageCache = NSCache<NSString, AnyObject>()
    
    func downloadImage(with urlString: String, completion: @escaping (_ image: UIImage?) -> Void) {
        
        if urlString == "None" {
            // Use default image
            completion(UIImage(named: "default.png"))
        } else if let cachedImage = imageCache.object(forKey: urlString as NSString) as? UIImage {
            // Use the cached image
            completion(cachedImage)
        } else {
            
            weak var weakSelf = self
            
            if let url = URL(string: urlString) {
                
                let task = URLSession.shared.dataTask(with: url) {
                    (data, response, error) in
                    
                    let httpResponse = response as? HTTPURLResponse
                    
                    if httpResponse!.statusCode != 200 {
                        DispatchQueue.main.async {
                            print("HTTP error: status code \(httpResponse!.statusCode)")
                            // Use default image
                            completion(UIImage(named: "default.png"))
                        }
                    } else if (data == nil && error != nil) {
                        DispatchQueue.main.async {
                            print("No data downloaded")
                            // Use default image
                            completion(UIImage(named: "default.png"))
                        }
                    } else {
                        // Download was successful
                        
                        if let image = UIImage(data: data!) {
                            // Everything worked!
                            DispatchQueue.main.async {
                                // Use downloaded image
                                weakSelf!.imageCache.setObject(image, forKey: urlString as NSString)
                                completion(image)
                            }
                        }
                    }
                }
                
                task.resume()
            }
        }
    }
    
    func clearCache() {
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf!.imageCache.removeAllObjects()
        }
    }
}
