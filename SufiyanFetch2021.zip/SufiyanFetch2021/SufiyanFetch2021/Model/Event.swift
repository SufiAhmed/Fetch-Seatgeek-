//
//  Event.swift
//  SufiyanFetch2021
//
//  Created by Sufiyan Ahmed on 2/5/21.
//
//  Purpose: Struct format in which to parse JSON Data of Seat geek API


import Foundation

// main root Object
struct Root: Codable
{
    let events : [Event]
}

// Event Array inside toot
struct Event: Codable
{
    let venue: Venue
    let performers: [Performers]
    let short_title: String
    let type: String
    let datetime_utc: String
}

// Venue object inside Event arry
struct Venue: Codable
{
    let display_location: String
}

// performers array inside Events array
struct Performers: Codable
{
   let images: Images
    let type: String
}

//images object inside performers Array
struct Images: Codable
{
    let huge: String
}

